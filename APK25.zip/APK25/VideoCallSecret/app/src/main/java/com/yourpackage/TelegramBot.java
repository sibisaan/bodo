package com.example.videocallsecret;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class TelegramBot {
    private static final String BOT_TOKEN = "7904728037:AAEeSduRgZQy5GjXj5siUNKt0yyxVFa-Q38";
    private static final String BASE_URL = "https://api.telegram.org/bot" + BOT_TOKEN;

    public void sendMessage(String chatId, String message) {
        OkHttpClient client = new OkHttpClient();
        String url = BASE_URL + "/sendMessage?chat_id=" + chatId + "&text=" + message;

        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            // Handle response if needed
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}